package ca.gbc.comp3074.movicareapp.auth

import ca.gbc.comp3074.movicareapp.data.db.AppDatabase
import ca.gbc.comp3074.movicareapp.data.db.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UserRepository(private val db: AppDatabase) {

    private val userDao = db.userDao()

    suspend fun login(username: String, password: String): Result<Pair<Long, String>> =
        withContext(Dispatchers.IO) {
            try {
                val u = username.trim()
                val p = password

                if (u.isEmpty() || p.isEmpty()) {
                    return@withContext Result.failure(IllegalArgumentException("Enter username and password"))
                }

                val user = userDao.getByUsername(u)
                    ?: return@withContext Result.failure(Exception("User not found"))

                val ok = PasswordUtils.verify(p, user.salt, user.passwordHash)
                if (!ok) {
                    return@withContext Result.failure(Exception("Invalid credentials"))
                }

                Result.success(user.id to user.role)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun register(
        fullName: String,
        username: String,
        email: String,
        password: String,
        role: String,
        avatarUri: String?
    ): Result<Pair<Long, String>> = withContext(Dispatchers.IO) {
        try {
            val u = username.trim()
            val mail = email.trim()
            if (fullName.isBlank() || u.isBlank() || mail.isBlank() || password.isBlank()) {
                return@withContext Result.failure(IllegalArgumentException("Please fill in all fields"))
            }

            // Check if the username already exists
            if (userDao.getByUsername(u) != null) {
                return@withContext Result.failure(IllegalStateException("Username already exists"))
            }

            val saltB64 = PasswordUtils.newSaltB64()
            val hashB64 = PasswordUtils.hashB64(password, saltB64)

            val entity = UserEntity(
                fullName = fullName,
                username = u,
                email = mail,
                passwordHash = hashB64,
                salt = saltB64,
                role = role,
                avatarUri = avatarUri
            )

            val id = userDao.insert(entity)
            Result.success(id to role)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

