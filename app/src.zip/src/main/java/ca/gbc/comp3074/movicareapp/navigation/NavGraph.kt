package ca.gbc.comp3074.movicareapp.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ca.gbc.comp3074.movicareapp.*

@Composable
fun AppNavHost() {
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = "welcome") {

        // Welcome
        composable("welcome") {
            WelcomeScreen(
                onLoginClick = { nav.navigate("login") },
                onSignupClick = { nav.navigate("signup") }
            )
        }

        // Login -> devuelve (userId, role)
        composable("login") {
            LoginScreen(
                onBackClick = { nav.popBackStack() },
                onLoginSuccess = { userId, role ->
                    nav.navigate("home/$userId/$role") {
                        popUpTo("welcome") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onGoToSignUp = { nav.navigate("signup") }
            )
        }

        // SignUp -> devuelve (userId, role) pero te mando a login como tenías
        composable("signup") {
            SignUpScreen(
                onBackClick = { nav.popBackStack() },
                onRegistrationSuccess = { _, _ ->
                    nav.navigate("login") {
                        popUpTo("welcome") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onLoginClick = {
                    nav.navigate("login") {
                        popUpTo("welcome") { inclusive = false }
                        launchSingleTop = true
                    }
                }
            )
        }

        // HOME con argumentos requeridos (userId y role)
        composable(
            route = "home/{userId}/{role}",
            arguments = listOf(
                navArgument("userId") { type = NavType.LongType },
                navArgument("role") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val userId = requireNotNull(backStackEntry.arguments?.getLong("userId")) { "userId is required" }
            val role = requireNotNull(backStackEntry.arguments?.getString("role")) { "role is required" }

            HomeScreen(
                userId = userId,
                role = role,
                onProfileClick = { nav.navigate("profile") }
            )
        }

        // PROFILE (sin userId)
        composable("profile") {
            ProfileScreen(
                onBackClick = { nav.popBackStack() },
                onLogoutClick = {
                    nav.navigate("welcome") {
                        popUpTo(0)
                        launchSingleTop = true
                    }
                },
                onMyHealthClick = { nav.navigate("myHealth") },
                onMedicationsClick = { nav.navigate("medications") },
                onFamilyClick = { nav.navigate("family") },
                onAppointmentsClick = { nav.navigate("appointments") },
                onAccountClick = { nav.navigate("account") }
            )
        }

        // FAMILY (diseño original: solo onBackClick)
        composable("family") {
            FamilyMembersScreen(onBackClick = { nav.popBackStack() })
        }

        // ACCOUNT (sin userId)
        composable("account") {
            AccountScreen(onBackClick = { nav.popBackStack() })
        }

        // MY HEALTH (sin userId)
        composable("myHealth") {
            MyHealthScreen(onBackClick = { nav.popBackStack() })
        }

        // MEDICATIONS (sin userId)
        composable("medications") {
            MedicationsScreen(
                onBackClick = { nav.popBackStack() },
                onAddMedicationClick = { nav.navigate("addMedication") }
            )
        }

        composable("addMedication") {
            AddMedicationScreen(onBackClick = { nav.popBackStack() })
        }

        // APPOINTMENTS (sin userId)
        composable("appointments") {
            AppointmentsScreen(
                onBackClick = { nav.popBackStack() },
                onAddAppointmentClick = { nav.navigate("addAppointment") }
            )
        }

        composable("addAppointment") {
            AddAppointmentScreen(onBackClick = { nav.popBackStack() })
        }
    }
}
